// ====== CONFIG ======
// Point this at wherever you run server/server.js.
// ws:// for local/plain, wss:// if the server is behind TLS.
const SIGNALING_URL = "ws://localhost:8080";

const ICE_SERVERS = [{ urls: "stun:stun.l.google.com:19302" }];
const CHUNK_SIZE = 16 * 1024; // 16KB per data-channel chunk
const BUFFER_THRESHOLD = 1 * 1024 * 1024; // back off if buffered > 1MB

const AVATAR_COLORS = ["#ef4444","#f97316","#eab308","#22c55e","#06b6d4","#3b82f6","#8b5cf6","#ec4899"];

// ====== STATE ======
let me = null;              // { name, avatar }
let ws = null;
let currentRoom = null;     // room code string, or null
let isHost = false;
let pc = null;              // RTCPeerConnection
let dc = null;              // RTCDataChannel
let peer = null;            // { name, avatar } of the other person
let incomingFile = null;    // { id, name, size, mime, received: [], bytesReceived }
let outgoingQueue = [];     // files waiting to send

// ====== DOM ======
const el = (id) => document.getElementById(id);
const screens = {
  setup: el("screen-setup"),
  lobby: el("screen-lobby"),
  room: el("screen-room"),
};
function showScreen(name) {
  Object.values(screens).forEach((s) => s.classList.add("hidden"));
  screens[name].classList.remove("hidden");
}

function avatarColorFor(letter) {
  const code = letter.charCodeAt(0) || 0;
  return AVATAR_COLORS[code % AVATAR_COLORS.length];
}
function makeAvatar(name) {
  const letter = (name || "?").trim().charAt(0).toUpperCase() || "?";
  return { letter, color: avatarColorFor(letter) };
}
function renderAvatar(target, avatar) {
  target.textContent = avatar.letter;
  target.style.background = avatar.color;
}

// ====== SETUP SCREEN (first run) ======
async function init() {
  const stored = await chrome.storage.local.get(["officeDropName", "officeDropAvatar"]);
  if (stored.officeDropName) {
    me = { name: stored.officeDropName, avatar: stored.officeDropAvatar };
    enterLobby();
  } else {
    showScreen("setup");
  }
}

el("setup-save").addEventListener("click", async () => {
  const name = el("setup-name").value.trim();
  if (!name) return;
  const avatar = makeAvatar(name);
  await chrome.storage.local.set({ officeDropName: name, officeDropAvatar: avatar });
  me = { name, avatar };
  enterLobby();
});
el("setup-name").addEventListener("keydown", (e) => {
  if (e.key === "Enter") el("setup-save").click();
});

// ====== LOBBY ======
function enterLobby() {
  renderAvatar(el("me-avatar"), me.avatar);
  el("me-name").textContent = me.name;
  showScreen("lobby");
  connectSignaling();
}

function connectSignaling() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
  ws = new WebSocket(SIGNALING_URL);

  ws.addEventListener("open", () => {
    setDot(true);
    send({ type: "hello", name: me.name, avatar: me.avatar });
    send({ type: "list-rooms" });
  });
  ws.addEventListener("close", () => {
    setDot(false);
    setTimeout(connectSignaling, 2000); // auto-reconnect
  });
  ws.addEventListener("error", () => setDot(false));
  ws.addEventListener("message", (evt) => handleSignalMessage(JSON.parse(evt.data)));
}

function setDot(online) {
  const dot = el("conn-dot");
  dot.classList.toggle("online", online);
  dot.classList.toggle("offline", !online);
}

function send(obj) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}

function handleSignalMessage(msg) {
  switch (msg.type) {
    case "rooms":
      renderRoomList(msg.rooms);
      break;
    case "room-created":
      currentRoom = msg.code;
      isHost = true;
      enterRoom();
      break;
    case "room-joined":
      currentRoom = msg.code;
      isHost = false;
      peer = msg.peer;
      enterRoom();
      startPeerConnection();
      break;
    case "peer-joined":
      peer = msg.peer;
      updatePeerBar();
      startPeerConnection(); // host initiates offer
      break;
    case "peer-left":
      peer = null;
      updatePeerBar();
      el("peer-status").textContent = "The other person left. Room stays open.";
      if (pc) { pc.close(); pc = null; dc = null; }
      break;
    case "signal":
      handleRTCSignal(msg.data);
      break;
    case "error":
      alert(msg.message);
      break;
  }
}

function renderRoomList(rooms) {
  const list = el("room-list");
  list.innerHTML = "";
  const empty = el("room-empty");
  if (!rooms.length) {
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");
  rooms.forEach((r) => {
    const li = document.createElement("li");
    const av = document.createElement("span");
    av.className = "avatar";
    renderAvatar(av, r.hostAvatar);
    const info = document.createElement("div");
    info.className = "room-info";
    info.innerHTML = `<span class="room-host">${escapeHtml(r.hostName)}'s room</span><br><span class="room-code-chip">${r.code}</span>`;
    li.appendChild(av);
    li.appendChild(info);
    li.addEventListener("click", () => joinRoom(r.code));
    list.appendChild(li);
  });
}

el("btn-create").addEventListener("click", () => send({ type: "create-room" }));
el("btn-join").addEventListener("click", () => {
  const code = el("pin-input").value.trim();
  if (code.length === 6) joinRoom(code);
});
el("pin-input").addEventListener("keydown", (e) => {
  if (e.key === "Enter") el("btn-join").click();
});
function joinRoom(code) {
  send({ type: "join-room", code });
}

// ====== ROOM SCREEN ======
function enterRoom() {
  el("room-code-label").textContent = currentRoom;
  el("chat-log").innerHTML = "";
  el("transfer-list").innerHTML = "";
  updatePeerBar();
  showScreen("room");
}

function updatePeerBar() {
  const bar = el("peers-bar");
  bar.innerHTML = "";
  const meAv = document.createElement("span");
  meAv.className = "avatar";
  renderAvatar(meAv, me.avatar);
  bar.appendChild(meAv);

  if (peer) {
    const peerAv = document.createElement("span");
    peerAv.className = "avatar";
    renderAvatar(peerAv, peer.avatar);
    bar.appendChild(peerAv);
    el("peer-status").textContent = `Connected with ${peer.name}`;
  } else {
    el("peer-status").textContent = isHost
      ? `Waiting for someone to join — share code ${currentRoom}`
      : "Connecting…";
  }
}

el("btn-leave").addEventListener("click", () => {
  send({ type: "leave-room" });
  if (pc) { pc.close(); pc = null; dc = null; }
  currentRoom = null;
  peer = null;
  showScreen("lobby");
  send({ type: "list-rooms" });
});

// ====== WEBRTC ======
function startPeerConnection() {
  pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });

  pc.onicecandidate = (e) => {
    if (e.candidate) send({ type: "signal", code: currentRoom, data: { candidate: e.candidate } });
  };
  pc.onconnectionstatechange = () => {
    if (pc.connectionState === "connected") {
      el("peer-status").textContent = `Connected with ${peer ? peer.name : "peer"}`;
    }
  };

  if (isHost) {
    dc = pc.createDataChannel("main");
    setupDataChannel();
    pc.createOffer()
      .then((offer) => pc.setLocalDescription(offer))
      .then(() => send({ type: "signal", code: currentRoom, data: { sdp: pc.localDescription } }));
  } else {
    pc.ondatachannel = (e) => {
      dc = e.channel;
      setupDataChannel();
    };
  }
}

async function handleRTCSignal(data) {
  if (!pc) return;
  if (data.sdp) {
    await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
    if (data.sdp.type === "offer") {
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      send({ type: "signal", code: currentRoom, data: { sdp: pc.localDescription } });
    }
  } else if (data.candidate) {
    try { await pc.addIceCandidate(new RTCIceCandidate(data.candidate)); } catch (_) {}
  }
}

function setupDataChannel() {
  dc.binaryType = "arraybuffer";
  dc.onopen = () => { el("peer-status").textContent = `Connected with ${peer ? peer.name : "peer"}`; };
  dc.onmessage = (e) => {
    if (typeof e.data === "string") {
      const msg = JSON.parse(e.data);
      handleDataChannelControl(msg);
    } else {
      handleIncomingChunk(e.data);
    }
  };
}

function handleDataChannelControl(msg) {
  switch (msg.type) {
    case "chat":
      renderChatMessage(msg.text, false, msg.from, msg.avatar);
      break;
    case "file-start":
      incomingFile = { id: msg.id, name: msg.name, size: msg.size, mime: msg.mime, chunks: [], bytesReceived: 0 };
      renderTransferRow(msg.id, msg.name, true);
      break;
    case "file-end":
      finishIncomingFile();
      break;
  }
}

function handleIncomingChunk(buf) {
  if (!incomingFile) return;
  incomingFile.chunks.push(buf);
  incomingFile.bytesReceived += buf.byteLength;
  updateTransferProgress(incomingFile.id, incomingFile.bytesReceived / incomingFile.size);
}

function finishIncomingFile() {
  if (!incomingFile) return;
  const blob = new Blob(incomingFile.chunks, { type: incomingFile.mime || "application/octet-stream" });
  const url = URL.createObjectURL(blob);
  const row = document.getElementById("t-" + incomingFile.id);
  if (row) {
    row.querySelector(".t-bar").remove();
    const a = document.createElement("a");
    a.href = url;
    a.download = incomingFile.name;
    a.textContent = "Download";
    row.appendChild(a);
  }
  incomingFile = null;
}

// ====== FILE SENDING ======
const dropZone = el("drop-zone");
["dragenter", "dragover"].forEach((evt) =>
  dropZone.addEventListener(evt, (e) => { e.preventDefault(); dropZone.classList.add("dragover"); })
);
["dragleave", "drop"].forEach((evt) =>
  dropZone.addEventListener(evt, (e) => { e.preventDefault(); dropZone.classList.remove("dragover"); })
);
dropZone.addEventListener("drop", (e) => {
  const files = e.dataTransfer.files;
  if (files.length) sendFile(files[0]);
});
el("file-input").addEventListener("change", (e) => {
  if (e.target.files.length) sendFile(e.target.files[0]);
  e.target.value = "";
});

async function sendFile(file) {
  if (!dc || dc.readyState !== "open") {
    alert("Not connected to the other person yet.");
    return;
  }
  const id = Math.random().toString(36).slice(2, 10);
  renderTransferRow(id, file.name, false);
  dc.send(JSON.stringify({ type: "file-start", id, name: file.name, size: file.size, mime: file.type }));

  const buf = await file.arrayBuffer();
  let offset = 0;
  while (offset < buf.byteLength) {
    if (dc.bufferedAmount > BUFFER_THRESHOLD) {
      await new Promise((r) => setTimeout(r, 50));
      continue;
    }
    const chunk = buf.slice(offset, offset + CHUNK_SIZE);
    dc.send(chunk);
    offset += chunk.byteLength;
    updateTransferProgress(id, offset / file.size);
  }
  dc.send(JSON.stringify({ type: "file-end", id }));
}

function renderTransferRow(id, name, incoming) {
  const list = el("transfer-list");
  const row = document.createElement("div");
  row.className = "transfer-item";
  row.id = "t-" + id;
  row.innerHTML = `<span class="t-name">${incoming ? "⬇ " : "⬆ "}${escapeHtml(name)}</span>
    <div class="t-bar"><div class="t-fill"></div></div>`;
  list.prepend(row);
}
function updateTransferProgress(id, ratio) {
  const row = document.getElementById("t-" + id);
  if (!row) return;
  const fill = row.querySelector(".t-fill");
  if (fill) fill.style.width = Math.min(100, Math.round(ratio * 100)) + "%";
}

// ====== CHAT ======
el("chat-send").addEventListener("click", sendChat);
el("chat-input").addEventListener("keydown", (e) => { if (e.key === "Enter") sendChat(); });

function sendChat() {
  const input = el("chat-input");
  const text = input.value.trim();
  if (!text || !dc || dc.readyState !== "open") return;
  dc.send(JSON.stringify({ type: "chat", text, from: me.name, avatar: me.avatar }));
  renderChatMessage(text, true, me.name, me.avatar);
  input.value = "";
}

function renderChatMessage(text, isMe, from) {
  const log = el("chat-log");
  const div = document.createElement("div");
  div.className = "msg " + (isMe ? "me" : "them");
  div.innerHTML = `<span class="who">${isMe ? "You" : escapeHtml(from)}</span>${escapeHtml(text)}`;
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str;
  return d.innerHTML;
}

init();
