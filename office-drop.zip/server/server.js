// Office Drop signaling server
// Purpose: help two browsers find each other and exchange WebRTC handshake
// data (SDP/ICE). It never sees file contents or chat messages — those
// flow directly peer-to-peer once the WebRTC connection is up.
// Everything here is in-memory. Nothing is written to disk or a database.
// Restarting the process simply clears all rooms.

const { WebSocketServer } = require("ws");

const PORT = process.env.PORT || 8080;
const ROOM_TTL_MS = 30 * 60 * 1000; // auto-expire an empty/abandoned room after 30 min

const wss = new WebSocketServer({ port: PORT });

// code -> { hostWs, hostName, hostAvatar, guestWs, guestName, guestAvatar, createdAt }
const rooms = new Map();

function generateCode() {
  let code;
  do {
    code = Math.floor(100000 + Math.random() * 900000).toString();
  } while (rooms.has(code));
  return code;
}

function publicRoomList() {
  return Array.from(rooms.entries())
    .filter(([, r]) => !r.guestWs) // only show rooms that still have a free slot
    .map(([code, r]) => ({ code, hostName: r.hostName, hostAvatar: r.hostAvatar, createdAt: r.createdAt }));
}

function broadcastRoomList() {
  const payload = JSON.stringify({ type: "rooms", rooms: publicRoomList() });
  wss.clients.forEach((client) => {
    if (client.readyState === client.OPEN) client.send(payload);
  });
}

function send(ws, obj) {
  if (ws && ws.readyState === ws.OPEN) ws.send(JSON.stringify(obj));
}

function cleanupRoomsForSocket(ws) {
  for (const [code, room] of rooms.entries()) {
    if (room.hostWs === ws) {
      // host left: notify guest if any, then kill the room
      if (room.guestWs) send(room.guestWs, { type: "peer-left" });
      rooms.delete(code);
    } else if (room.guestWs === ws) {
      // guest left: room stays open for someone else to join
      room.guestWs = null;
      room.guestName = null;
      room.guestAvatar = null;
      send(room.hostWs, { type: "peer-left" });
    }
  }
}

wss.on("connection", (ws) => {
  ws.isAlive = true;
  ws.on("pong", () => { ws.isAlive = true; });

  ws.meta = { name: null, avatar: null, roomCode: null };

  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }

    switch (msg.type) {
      case "hello": {
        ws.meta.name = String(msg.name || "Guest").slice(0, 20);
        ws.meta.avatar = msg.avatar || { letter: "?", color: "#999" };
        break;
      }

      case "list-rooms": {
        send(ws, { type: "rooms", rooms: publicRoomList() });
        break;
      }

      case "create-room": {
        const code = generateCode();
        rooms.set(code, {
          hostWs: ws,
          hostName: ws.meta.name,
          hostAvatar: ws.meta.avatar,
          guestWs: null,
          guestName: null,
          guestAvatar: null,
          createdAt: Date.now(),
        });
        ws.meta.roomCode = code;
        send(ws, { type: "room-created", code });
        broadcastRoomList();
        break;
      }

      case "join-room": {
        const code = String(msg.code || "").trim();
        const room = rooms.get(code);
        if (!room) { send(ws, { type: "error", message: "That room code doesn't exist." }); return; }
        if (room.guestWs) { send(ws, { type: "error", message: "That room is already full." }); return; }

        room.guestWs = ws;
        room.guestName = ws.meta.name;
        room.guestAvatar = ws.meta.avatar;
        ws.meta.roomCode = code;

        send(ws, { type: "room-joined", code, peer: { name: room.hostName, avatar: room.hostAvatar } });
        send(room.hostWs, { type: "peer-joined", peer: { name: ws.meta.name, avatar: ws.meta.avatar } });
        broadcastRoomList();
        break;
      }

      case "leave-room": {
        cleanupRoomsForSocket(ws);
        ws.meta.roomCode = null;
        broadcastRoomList();
        break;
      }

      case "signal": {
        // Relay WebRTC offer/answer/ICE candidates between the two peers in a room.
        const room = rooms.get(msg.code);
        if (!room) return;
        const target = room.hostWs === ws ? room.guestWs : room.hostWs;
        send(target, { type: "signal", data: msg.data });
        break;
      }
    }
  });

  ws.on("close", () => {
    cleanupRoomsForSocket(ws);
    broadcastRoomList();
  });
});

// Heartbeat: drop dead sockets, keep others alive through idle-timeout proxies.
const heartbeat = setInterval(() => {
  wss.clients.forEach((ws) => {
    if (ws.isAlive === false) return ws.terminate();
    ws.isAlive = false;
    ws.ping();
  });
}, 30000);

// Expire stale empty rooms.
setInterval(() => {
  const now = Date.now();
  for (const [code, room] of rooms.entries()) {
    if (!room.guestWs && now - room.createdAt > ROOM_TTL_MS) rooms.delete(code);
  }
  broadcastRoomList();
}, 60000);

wss.on("close", () => clearInterval(heartbeat));

console.log(`Office Drop signaling server listening on ws://localhost:${PORT}`);
